package ar.edu.unju.fi.ejercicio2;

public class Main {

	public static void main(String[] args) {
		String pais="Argentina";
		int edad=18;
		double altura=18.42;
		double precio=32.45;
		String numerotel="3886514323";
		double coseno=Math.cos(0.5);
		System.out.println(pais);
		System.out.println(edad);
		System.out.println(altura);
		System.out.println(precio);
		System.out.println(numerotel);
		System.out.println(coseno);
	
	}

}
