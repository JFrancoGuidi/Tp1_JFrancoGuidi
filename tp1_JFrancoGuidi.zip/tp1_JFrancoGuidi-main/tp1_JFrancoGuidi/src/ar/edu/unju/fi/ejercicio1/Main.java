package ar.edu.unju.fi.ejercicio1;

public class Main {

	public static void main(String[] args) {
		int a=2;
		int b=5;
		int c=23;
		int d=12;
		int e=8;
		double prom=(a+b+c+d+e)/5;
		System.out.println("El promedio es: "+prom);
	}

}
